"""
Video Downloader - a Streamlit web application for downloading publicly
accessible videos you are authorized to download, powered by yt-dlp.

Run with:
    streamlit run app.py
"""

import mimetypes
import os

import streamlit as st

from downloader.extractor import extract_video_info, ExtractionError, VideoInfo
from downloader.downloader import download_video, DownloadError
from utils.helpers import (
    check_ffmpeg_available,
    cleanup_file,
    cleanup_old_temp_files,
    format_duration,
    format_filesize,
    is_valid_url,
    load_css,
)


# --------------------------------------------------------------------------
# Page configuration
# --------------------------------------------------------------------------

st.set_page_config(
    page_title="Video Downloader",
    page_icon=None,
    layout="centered",
    initial_sidebar_state="collapsed",
)

# Inject the custom stylesheet. All visual styling (colors, fonts,
# animations, card layout) lives in static/style.css - this keeps the
# Python logic clean and the look easy to customize separately.
_CSS_PATH = os.path.join(os.path.dirname(__file__), "static", "style.css")
st.markdown(load_css(_CSS_PATH), unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Session state initialization
# --------------------------------------------------------------------------

def init_session_state() -> None:
    """Ensure all keys used across reruns exist in session state."""
    defaults = {
        "video_info": None,
        "video_url": "",
        "downloaded_file_path": None,
        "downloaded_file_name": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


init_session_state()

# Best-effort cleanup of old temporary files from previous sessions.
cleanup_old_temp_files()


# --------------------------------------------------------------------------
# Hero header
# --------------------------------------------------------------------------

st.markdown(
    """
    <div class="vd-hero vd-animate">
        <h1>Video Downloader</h1>
        <p>Enter a publicly accessible video URL that you are authorized
        to download. Fetch its details, choose a quality, and download it.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

if not check_ffmpeg_available():
    st.warning(
        "FFmpeg was not detected on this system. Some downloads that require "
        "merging separate video and audio streams, or converting to audio, "
        "may fail. See the README for installation instructions."
    )


# --------------------------------------------------------------------------
# Step 1: URL input and information fetch
# --------------------------------------------------------------------------

st.markdown('<div class="vd-card vd-animate vd-animate-delay-1">', unsafe_allow_html=True)
st.markdown('<div class="vd-card-title">Video URL</div>', unsafe_allow_html=True)

with st.form("url_form"):
    url_input = st.text_input(
        "Video URL",
        value=st.session_state.video_url,
        placeholder="https://example.com/watch?v=...",
        label_visibility="collapsed",
    )
    fetch_submitted = st.form_submit_button("Fetch video information", type="primary")

st.markdown("</div>", unsafe_allow_html=True)

if fetch_submitted:
    if not is_valid_url(url_input):
        st.error("Please enter a valid, non-empty video URL.")
    else:
        st.session_state.video_url = url_input.strip()
        st.session_state.video_info = None
        st.session_state.downloaded_file_path = None
        st.session_state.downloaded_file_name = None

        with st.spinner("Fetching video information..."):
            try:
                info: VideoInfo = extract_video_info(st.session_state.video_url)
                st.session_state.video_info = info
                st.success("Video information retrieved successfully.")
            except ExtractionError as exc:
                st.error(str(exc))
            except Exception:
                st.error("An unexpected error occurred while fetching video information.")


# --------------------------------------------------------------------------
# Step 2: Display metadata and quality selection
# --------------------------------------------------------------------------

info: VideoInfo = st.session_state.video_info

if info is not None:
    st.markdown('<div class="vd-card vd-animate">', unsafe_allow_html=True)
    st.markdown('<div class="vd-card-title">Video details</div>', unsafe_allow_html=True)

    col_thumb, col_meta = st.columns([1, 1.4])

    with col_thumb:
        st.markdown('<div class="vd-thumb-wrap">', unsafe_allow_html=True)
        if info.thumbnail:
            st.image(info.thumbnail, use_container_width=True)
        else:
            st.write("No thumbnail available.")
        st.markdown("</div>", unsafe_allow_html=True)

    with col_meta:
        st.markdown(
            f"""
            <div class="vd-meta-row">
                <span class="vd-meta-label">Title</span>
                <span class="vd-meta-value">{info.title}</span>
            </div>
            <div class="vd-meta-row">
                <span class="vd-meta-label">Uploader</span>
                <span class="vd-meta-value">{info.uploader}</span>
            </div>
            <div class="vd-meta-row">
                <span class="vd-meta-label">Duration</span>
                <span class="vd-meta-value">{format_duration(info.duration)}</span>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("</div>", unsafe_allow_html=True)

    # --- Quality selection card ---
    st.markdown('<div class="vd-card vd-animate vd-animate-delay-1">', unsafe_allow_html=True)
    st.markdown('<div class="vd-card-title">Choose a quality</div>', unsafe_allow_html=True)

    quality_labels = [q.label for q in info.qualities]
    quality_lookup = {q.label: q for q in info.qualities}

    def _format_option(label: str) -> str:
        option = quality_lookup[label]
        size_text = format_filesize(option.filesize)
        return f"{label} ({size_text})" if option.filesize else label

    selected_label = st.radio(
        "Available formats",
        options=quality_labels,
        format_func=_format_option,
        label_visibility="collapsed",
    )

    selected_quality = quality_lookup[selected_label]

    ffmpeg_ok = check_ffmpeg_available()

    if selected_quality.needs_merge and not ffmpeg_ok:
        st.error(
            "This quality requires FFmpeg to merge separate video and audio "
            "streams, but FFmpeg was not found. Please install it first, or "
            "choose a different quality."
        )
        download_clicked = False
    else:
        download_clicked = st.button("Download selected quality", type="primary")

    st.markdown("</div>", unsafe_allow_html=True)

    if download_clicked:
        st.markdown('<div class="vd-card vd-animate">', unsafe_allow_html=True)
        st.markdown('<div class="vd-card-title">Downloading</div>', unsafe_allow_html=True)

        progress_bar = st.progress(0, text="Starting download...")
        status_text = st.empty()

        def progress_hook(status: dict) -> None:
            """
            Update the Streamlit progress bar based on yt-dlp's
            reported download status. yt-dlp calls this synchronously
            during the download.
            """
            if status.get("status") == "downloading":
                total = status.get("total_bytes") or status.get("total_bytes_estimate")
                downloaded = status.get("downloaded_bytes", 0)
                if total:
                    fraction = min(downloaded / total, 1.0)
                    progress_bar.progress(
                        fraction, text=f"Downloading... {int(fraction * 100)}%"
                    )
                else:
                    status_text.write("Downloading...")
            elif status.get("status") == "finished":
                progress_bar.progress(1.0, text="Processing download...")

        try:
            is_audio_only = selected_quality.label == "Audio only"
            file_path = download_video(
                url=st.session_state.video_url,
                format_selector=selected_quality.format_id,
                title=info.title,
                is_audio_only=is_audio_only,
                progress_callback=progress_hook,
            )

            # Clean up any previously downloaded file for this session
            # before storing the new one.
            if st.session_state.downloaded_file_path:
                cleanup_file(st.session_state.downloaded_file_path)

            st.session_state.downloaded_file_path = file_path
            st.session_state.downloaded_file_name = os.path.basename(file_path)

            progress_bar.progress(1.0, text="Download complete.")
            status_text.empty()
            st.success("The video was downloaded successfully. Use the button below to save it.")
            st.balloons()

        except DownloadError as exc:
            progress_bar.empty()
            status_text.empty()
            st.error(str(exc))
        except Exception:
            progress_bar.empty()
            status_text.empty()
            st.error("An unexpected error occurred during the download.")

        st.markdown("</div>", unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Step 3: Provide the finished file to the user
# --------------------------------------------------------------------------

if st.session_state.downloaded_file_path and os.path.exists(st.session_state.downloaded_file_path):
    st.markdown('<div class="vd-card vd-animate">', unsafe_allow_html=True)
    st.markdown(
        '<div class="vd-card-title">Your download is ready '
        '<span class="vd-badge vd-badge-success">Ready</span></div>',
        unsafe_allow_html=True,
    )

    # Read the full file into memory up front rather than passing a live
    # file handle. This avoids relying on a server-side reference that can
    # go stale if the app reruns or restarts before the button is clicked,
    # and ensures the browser gets a correct filename and content type
    # instead of falling back to a generic name.
    with open(st.session_state.downloaded_file_path, "rb") as file_handle:
        file_bytes = file_handle.read()

    guessed_mime, _ = mimetypes.guess_type(st.session_state.downloaded_file_name)

    st.download_button(
        label="Save file to your computer",
        data=file_bytes,
        file_name=st.session_state.downloaded_file_name,
        mime=guessed_mime or "application/octet-stream",
    )
    st.markdown("</div>", unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Footer
# --------------------------------------------------------------------------

st.markdown(
    """
    <div class="vd-footer">
        Only download videos that are publicly accessible and that you are
        authorized to download. This tool does not bypass DRM, paywalls,
        logins, or any other access controls.
    </div>
    """,
    unsafe_allow_html=True,
)
