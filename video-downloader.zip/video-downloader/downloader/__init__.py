"""Downloader package: video info extraction and download logic."""
