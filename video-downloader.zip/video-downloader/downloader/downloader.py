"""
Video downloading logic using yt-dlp.

This module handles the actual download of a video/audio stream to a
temporary location on disk, given a format selector produced by
extractor.py. It reports progress through a callback so the UI can show
a live progress bar.
"""

import os
from typing import Callable, Optional

import yt_dlp

from utils.helpers import get_temp_download_dir, sanitize_filename


class DownloadError(Exception):
    """Raised when a download fails for any reason."""


ProgressCallback = Callable[[dict], None]


def download_video(
    url: str,
    format_selector: str,
    title: str,
    is_audio_only: bool = False,
    progress_callback: Optional[ProgressCallback] = None,
) -> str:
    """
    Download the given URL using the specified yt-dlp format selector.

    Returns the full path to the downloaded file on success.
    Raises DownloadError with a human-readable message on failure.
    """
    output_dir = get_temp_download_dir()
    safe_title = sanitize_filename(title)
    # yt-dlp fills in the real extension via the %(ext)s template.
    output_template = os.path.join(output_dir, f"{safe_title}.%(ext)s")

    ydl_opts = {
        "format": format_selector,
        "outtmpl": output_template,
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "merge_output_format": "mp4" if not is_audio_only else None,
    }

    if progress_callback is not None:
        ydl_opts["progress_hooks"] = [progress_callback]

    if is_audio_only:
        ydl_opts["postprocessors"] = [
            {
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }
        ]

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            downloaded_path = ydl.prepare_filename(info)

            # When audio postprocessing runs, the final file has a .mp3
            # extension rather than the original container extension.
            if is_audio_only:
                base, _ = os.path.splitext(downloaded_path)
                mp3_path = base + ".mp3"
                if os.path.exists(mp3_path):
                    downloaded_path = mp3_path

    except yt_dlp.utils.DownloadError as exc:
        raise DownloadError(_friendly_download_error(str(exc))) from exc
    except Exception as exc:  # noqa: BLE001 - never let raw exceptions surface to the UI
        raise DownloadError(
            "An unexpected error occurred during the download."
        ) from exc

    if not os.path.exists(downloaded_path):
        raise DownloadError("The download finished but the output file could not be found.")

    return downloaded_path


def _friendly_download_error(raw_message: str) -> str:
    """
    Translate common yt-dlp download error substrings into short,
    human-readable messages.
    """
    message = raw_message.lower()

    if "ffmpeg" in message or "ffprobe" in message:
        return "FFmpeg is required to complete this download but was not found on your system."
    if "permission" in message:
        return "A file permission error occurred while saving the download."
    if "no space" in message:
        return "There is not enough disk space to complete this download."
    if "network" in message or "urlopen error" in message or "timed out" in message:
        return "A network error interrupted the download. Please try again."
    if "unsupported" in message:
        return "The selected format is not supported for this video."
    if "unavailable" in message:
        return "This video became unavailable during the download."

    return "The download could not be completed. Please try again."
