"""
Video information extraction using yt-dlp.

This module is responsible only for reading publicly available metadata
and format information about a video URL. It never downloads media
itself; that responsibility belongs to downloader.py.
"""

from dataclasses import dataclass, field
from typing import List, Optional

import yt_dlp


class ExtractionError(Exception):
    """Raised when video information cannot be retrieved for any reason."""


@dataclass
class QualityOption:
    """
    Represents a single downloadable quality choice presented to the user.

    label:        Human-readable label shown in the UI (e.g. "1080p").
    format_id:    The yt-dlp format selector string used for downloading.
    resolution:   Resolution string, or "Audio only" for audio-only options.
    filesize:     Approximate size in bytes, if known.
    ext:          File extension of the resulting download.
    needs_merge:  True when video and audio are separate streams that
                  require FFmpeg to combine.
    """

    label: str
    format_id: str
    resolution: str
    filesize: Optional[int]
    ext: str
    needs_merge: bool = False


@dataclass
class VideoInfo:
    """Holds the metadata and quality options extracted for a video."""

    title: str
    uploader: str
    duration: Optional[int]
    thumbnail: Optional[str]
    webpage_url: str
    qualities: List[QualityOption] = field(default_factory=list)


# The "standard" resolution buckets we try to offer, mapped to a maximum
# height used to select the closest matching real format.
_TARGET_RESOLUTIONS = [
    ("1080p", 1080),
    ("720p", 720),
    ("480p", 480),
    ("360p", 360),
]


def _build_ydl_opts() -> dict:
    """
    Build the yt-dlp options used purely for information extraction.

    'skip_download' ensures no media is downloaded during this step, and
    quiet/no_warnings keep console output clean.
    """
    return {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
    }


def extract_video_info(url: str) -> VideoInfo:
    """
    Fetch metadata and available formats for a given video URL.

    Raises ExtractionError with a human-readable message on any failure,
    so calling code (the Streamlit UI) never has to handle raw yt-dlp
    or network exceptions directly.
    """
    ydl_opts = _build_ydl_opts()

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
    except yt_dlp.utils.DownloadError as exc:
        raise ExtractionError(_friendly_extraction_error(str(exc))) from exc
    except Exception as exc:  # noqa: BLE001 - convert any failure to a friendly message
        raise ExtractionError(
            "An unexpected error occurred while reading video information."
        ) from exc

    if not info:
        raise ExtractionError("No information could be retrieved for this URL.")

    # If a playlist slipped through, use the first entry.
    if "entries" in info and info["entries"]:
        info = info["entries"][0]

    qualities = _build_quality_options(info.get("formats", []))

    if not qualities:
        raise ExtractionError(
            "No downloadable formats were found for this video."
        )

    return VideoInfo(
        title=info.get("title") or "Unknown title",
        uploader=info.get("uploader") or info.get("channel") or "Unknown uploader",
        duration=info.get("duration"),
        thumbnail=info.get("thumbnail"),
        webpage_url=info.get("webpage_url") or url,
        qualities=qualities,
    )


def _build_quality_options(formats: list) -> List[QualityOption]:
    """
    Translate the raw list of yt-dlp formats into a small, practical set
    of quality options: Best available, common resolution buckets, and
    Audio only. Only options that actually exist for this video appear.
    """
    options: List[QualityOption] = []

    if not formats:
        return options

    # --- Best available (video + audio, let yt-dlp pick the best pair) ---
    has_video = any(f.get("vcodec") not in (None, "none") for f in formats)
    if has_video:
        options.append(
            QualityOption(
                label="Best available",
                # Prefer M4A/AAC audio when merging into an MP4 container.
                # Opus audio (yt-dlp's default "bestaudio") merged into MP4
                # plays back silently in many players, including Windows
                # Media Player, even though the merge itself succeeds.
                format_id="bestvideo+bestaudio[ext=m4a]/bestvideo+bestaudio/best",
                resolution="Best",
                filesize=None,
                ext="mp4",
                needs_merge=True,
            )
        )

    # --- Resolution buckets ---
    video_formats = [
        f for f in formats
        if f.get("vcodec") not in (None, "none") and f.get("height")
    ]

    for label, target_height in _TARGET_RESOLUTIONS:
        candidates = [f for f in video_formats if f.get("height") == target_height]
        if not candidates:
            # Accept the closest lower resolution as a reasonable fallback.
            candidates = [f for f in video_formats if f.get("height") and f["height"] <= target_height]
            candidates.sort(key=lambda f: f["height"], reverse=True)
            candidates = candidates[:1] if candidates else []

        if not candidates:
            continue

        chosen = candidates[0]
        has_audio = chosen.get("acodec") not in (None, "none")
        format_selector = (
            chosen["format_id"]
            if has_audio
            # Prefer M4A/AAC audio for compatibility when merging into MP4;
            # fall back to any available audio if M4A isn't offered.
            else f"{chosen['format_id']}+bestaudio[ext=m4a]/{chosen['format_id']}+bestaudio/best"
        )

        options.append(
            QualityOption(
                label=label,
                format_id=format_selector,
                resolution=f"{chosen.get('height')}p",
                filesize=chosen.get("filesize") or chosen.get("filesize_approx"),
                ext=chosen.get("ext", "mp4"),
                needs_merge=not has_audio,
            )
        )

    # --- Audio only ---
    audio_formats = [
        f for f in formats
        if f.get("vcodec") in (None, "none") and f.get("acodec") not in (None, "none")
    ]
    if audio_formats:
        # Prefer the highest bitrate audio-only stream.
        audio_formats.sort(key=lambda f: f.get("abr") or 0, reverse=True)
        best_audio = audio_formats[0]
        options.append(
            QualityOption(
                label="Audio only",
                format_id="bestaudio/best",
                resolution="Audio only",
                filesize=best_audio.get("filesize") or best_audio.get("filesize_approx"),
                ext="mp3",
                needs_merge=False,
            )
        )

    return options


def _friendly_extraction_error(raw_message: str) -> str:
    """
    Translate common yt-dlp error substrings into short, human-readable
    messages instead of exposing raw library output to the user.
    """
    message = raw_message.lower()

    if "unsupported url" in message:
        return "This website or URL is not supported."
    if "video unavailable" in message:
        return "This video is unavailable. It may have been removed or made private."
    if "private" in message:
        return "This video is private and cannot be accessed."
    if "sign in" in message or "login" in message:
        return "This video requires authentication and cannot be downloaded."
    if "unable to download webpage" in message or "urlopen error" in message:
        return "A network error occurred while trying to reach this URL."
    if "404" in message:
        return "The video could not be found (error 404)."
    if "geo" in message and "restrict" in message:
        return "This video is not available in your region."

    return "This video could not be processed. Please check the URL and try again."
