"""
Helper utilities for the Video Downloader application.

This module contains small, reusable functions that do not belong to
either the extraction or downloading logic directly: formatting values
for display, checking for FFmpeg, building safe filenames, and cleaning
up temporary files.
"""

import os
import re
import shutil
import subprocess
import tempfile


def load_css(css_path: str) -> str:
    """
    Read a CSS file from disk and return it ready to inject into Streamlit
    via st.markdown(..., unsafe_allow_html=True).

    Returns an empty style block instead of raising if the file is
    missing, so a missing stylesheet never crashes the app - it just
    falls back to Streamlit's default look.
    """
    try:
        with open(css_path, "r", encoding="utf-8") as css_file:
            css_content = css_file.read()
    except OSError:
        return "<style></style>"

    return f"<style>{css_content}</style>"


def is_valid_url(url: str) -> bool:
    """
    Perform a lightweight sanity check on a URL string.

    This does not guarantee the URL is downloadable, only that it looks
    like a well-formed http/https URL. yt-dlp performs the real validation
    when it tries to extract information from it.
    """
    if not url or not url.strip():
        return False

    pattern = re.compile(
        r"^(https?://)"          # must start with http:// or https://
        r"([A-Za-z0-9\-._~%]+)"  # domain
        r"(\.[A-Za-z0-9\-._~%]+)+"  # at least one dot-separated segment
        r"(:[0-9]{1,5})?"        # optional port
        r"(/[^\s]*)?$"           # optional path/query
    )
    return bool(pattern.match(url.strip()))


def check_ffmpeg_available() -> bool:
    """
    Check whether FFmpeg is installed and reachable from the terminal.

    Returns True if FFmpeg can be executed, False otherwise. This is used
    to warn the user before they attempt a download that requires merging
    separate video and audio streams.
    """
    ffmpeg_path = shutil.which("ffmpeg")
    if ffmpeg_path is None:
        return False

    try:
        result = subprocess.run(
            [ffmpeg_path, "-version"],
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.SubprocessError, OSError):
        return False


def format_duration(seconds) -> str:
    """
    Convert a duration in seconds into a human-readable HH:MM:SS string.

    Falls back to a placeholder if the duration is missing or invalid.
    """
    if seconds is None:
        return "Unknown"

    try:
        total_seconds = int(seconds)
    except (ValueError, TypeError):
        return "Unknown"

    hours, remainder = divmod(total_seconds, 3600)
    minutes, secs = divmod(remainder, 60)

    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def format_filesize(num_bytes) -> str:
    """
    Convert a byte count into a human-readable size string (KB, MB, GB).

    Returns "Unknown size" when the value is missing.
    """
    if num_bytes is None:
        return "Unknown size"

    try:
        size = float(num_bytes)
    except (ValueError, TypeError):
        return "Unknown size"

    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024.0:
            return f"{size:.1f} {unit}"
        size /= 1024.0

    return f"{size:.1f} TB"


def sanitize_filename(filename: str) -> str:
    """
    Remove characters that are unsafe for filenames on Windows and other
    platforms, and trim the result to a reasonable length.
    """
    if not filename:
        return "video"

    # Remove characters not allowed in Windows filenames.
    cleaned = re.sub(r'[\\/*?:"<>|]', "", filename)
    # Collapse whitespace and strip leading/trailing spaces or dots.
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" .")

    if not cleaned:
        return "video"

    # Keep filenames from becoming unreasonably long.
    return cleaned[:150]


def get_temp_download_dir() -> str:
    """
    Create (if needed) and return a dedicated temporary directory for
    storing downloads before they are handed to the user.
    """
    temp_dir = os.path.join(tempfile.gettempdir(), "video_downloader_app")
    os.makedirs(temp_dir, exist_ok=True)
    return temp_dir


def cleanup_file(file_path: str) -> None:
    """
    Safely delete a file if it exists. Any errors are silently ignored
    since this is best-effort cleanup and should never crash the app.
    """
    try:
        if file_path and os.path.exists(file_path):
            os.remove(file_path)
    except OSError:
        pass


def cleanup_old_temp_files(max_age_seconds: int = 3600) -> None:
    """
    Remove files from the temporary download directory that are older
    than max_age_seconds. This prevents the temp folder from growing
    indefinitely across multiple app sessions.
    """
    temp_dir = get_temp_download_dir()

    try:
        now = os.path.getmtime(temp_dir)
    except OSError:
        return

    for entry in os.listdir(temp_dir):
        full_path = os.path.join(temp_dir, entry)
        try:
            if os.path.isfile(full_path):
                file_age = now - os.path.getmtime(full_path)
                if file_age > max_age_seconds:
                    os.remove(full_path)
        except OSError:
            continue
